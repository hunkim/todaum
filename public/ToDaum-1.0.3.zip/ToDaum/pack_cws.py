from pathlib import Path
import zipfile

root = Path("/workspace/todum/extension")
out = Path("/home/box/Downloads/ToDaum-1.0.1-cws.zip")
out.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(root)
        if rel.parts[0] in {"store"} or rel.name in {"pack.py", "pack_cws.py"}:
            continue
        z.write(p, rel.as_posix())
        print(rel)
print("bytes", out.stat().st_size)
